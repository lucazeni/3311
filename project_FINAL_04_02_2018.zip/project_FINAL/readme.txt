Project for 3311 created by Luca Zeni and Alex Meli #
#####################################################

DUE DATE: APRIL 5th 2018

1. There is a script file "project.sh" which executes all the files in the /tests/acceptance/student and /tests/acceptance/instructor test.
   The results will appear in project_output folder for a comparison between "actual" vs "expected".

2. Please read course project "EECS3311-W18 – Tracker Project"

3. to execute on terminal /EIFGENs/tracker/W_code/tracker -i (interactive mode) (-b is batch mode) 

