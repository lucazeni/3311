#!/bin/sh

student=./tracker-project/tests/acceptance/student
instructor=./tracker-project/tests/acceptance/instructor
s_results=./project_output/student
i_results=./project_output/instructor

mkdir -p $s_results
mkdir -p $i_results

for i in "$instructor"/*.txt
do
  ./tracker-project/EIFGENs/tracker/W_code/tracker -b $i > $i_results/actual.$(basename $i)
  ./oracle.exe -b $i > $i_results/expected.$(basename $i)
  diff -s $i_results/expected.$(basename $i) $i_results/actual.$(basename $i)
done

for i in $student/*.txt
do
  ./tracker-project/EIFGENs/tracker/W_code/tracker -b $i > $s_results/actual.$(basename $i)
  ./oracle.exe -b $i > $s_results/expected.$(basename $i)
  diff -s  $s_results/expected.$(basename $i) $s_results/actual.$(basename $i)
done

